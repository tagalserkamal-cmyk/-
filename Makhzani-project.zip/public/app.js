'use strict';
const $=s=>document.querySelector(s),APP=$('#APP');
const IC={
home:'<path d="M3 11l9-8 9 8v10H3z"/><path d="M9 21v-6h6v6"/>',
pos:'<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6"/>',
items:'<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
cust:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
buy:'<path d="M2 6h12v11H2z"/><path d="M14 9h4l4 4v4h-8"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
rep:'<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
set:'<path d="M4 7h9M17 7h3M4 12h3M11 12h9M4 17h11M19 17h1"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="17" r="2"/>',
more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
plus:'<path d="M12 5v14M5 12h14"/>',minus:'<path d="M5 12h14"/>',
search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
up:'<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',down:'<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
file:'<path d="M6 2h8l5 5v15H6z"/><path d="M14 2v5h5"/>',
print:'<path d="M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z"/>',
out:'<path d="M9 21H4V3h5M16 17l5-5-5-5M21 12H9"/>',
trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',
key:'<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
exp:'<path d="M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7l2-3h12"/><circle cx="16.5" cy="13.5" r="1.2"/>',
moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>'};
const ic=(n,s)=>`<svg class="i" viewBox="0 0 24 24"${s?` style="width:${s}px;height:${s}px"`:''}>${IC[n]}</svg>`;
const logo=()=>`<svg class="logo" viewBox="0 0 100 100"><defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f2130"/><stop offset="1" stop-color="#15384c"/></linearGradient></defs><rect width="100" height="100" rx="22" fill="url(#lg)"/><ellipse cx="50" cy="83" rx="26" ry="5" fill="#000" opacity=".25"/><polygon points="50,20 76,35 50,50 24,35" fill="#8de8da"/><polygon points="24,35 50,50 50,80 24,65" fill="#35b8a8"/><polygon points="50,50 76,35 76,65 50,80" fill="#1f8c85"/><polygon points="39.6,26 65.6,41 60.4,44 34.4,29" fill="#e2faf6" opacity=".7"/><polygon points="34.4,41 44.8,47 44.8,77 34.4,71" fill="#c4efe8" opacity=".75"/></svg>`;
const brandTxt=()=>`<div><div class=bn>${esc(S.shop||'مخزني')}</div><div class=bs>نظام المبيعات والمخزون</div></div>`;

const fmt=n=>Math.round(+n||0).toLocaleString('en'),U=n=>(+n||0).toFixed(2);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
const monthStart=()=>today().slice(0,8)+'01';
const dt=t=>new Date(t).toLocaleDateString('en-GB'),dtm=t=>new Date(t).toLocaleString('en-GB',{dateStyle:'short',timeStyle:'short'});
const byName=(a,b)=>(a.n||'').localeCompare(b.n||'','ar');
const cd=c=>c?`<bdi dir="ltr">${esc(c)}</bdi>`:'';
const isLow=i=>i.qty!=null&&(i.qty<=0||(i.min>0&&i.qty<=i.min));
const qv=i=>i.qty==null?'—':i.qty;
const qp=i=>{const c=i.qty==null?'na':i.qty<=0?'low':isLow(i)?'warn':'ok',t=i.qty==null?'':i.qty<=0?'نفدت':isLow(i)?'قليلة':'';
  return `<div class=q><span class="qv ${c} num">${qv(i)}</span>${t?`<small class="qs ${c}">${t}</small>`:''}</div>`};
const qb=qp;
const itemHead='<div class="tr h"><div>الصنف</div><div>الكود</div><div class=q>الكمية</div><div>السعر</div></div>';
const itemRow=(i,click)=>`<div class="tr${click?' cl':''}" ${click?`onclick="${click}"`:''}><div class=nm>${esc(i.n)}</div><div class=cd>${cd(i.c)||'—'}</div>${qp(i)}<div class="pr num"><b>${sdg(i.p)}</b><small>ج</small>${isAdmin()?`<span class=usd>$${U(i.p)}</span>`:''}</div></div>`;
const empty=m=>`<div class=empty>${m}</div>`;
const rid=()=>Array.from(crypto.getRandomValues(new Uint8Array(5)),b=>b.toString(16).padStart(2,'0')).join('');
let toastT;function toast(m,bad){const t=$('#toast');t.textContent=m;t.className='on'+(bad?' bad':'');clearTimeout(toastT);toastT=setTimeout(()=>t.className='',2800)}
const err=e=>toast(e.message||String(e),1);

let me=null,S={rate:11000,shop:''},D={items:[],customers:[],sales:[],purchases:[],users:[]},ST={today:0,month:0,debt:0},SC={},RS={k:'',list:[],exp:[]},ES={k:'',list:[]},INFO=null;
let TOK=localStorage.tok||'',ver=-1,es=null,online=false,saving=false;
let cart=[],tab='dash',Q={n:60},R={f:today(),t:today()},E={f:monthStart(),t:today()},P={c:'',d:'',p:''},BI='';
const isAdmin=()=>me&&me.role==='admin';
const sdg=u=>fmt(u*S.rate);

// ---------- المظهر ----------
function setTheme(t){document.documentElement.dataset.t=t;localStorage.theme=t;document.querySelector('meta[name=theme-color]').content=t==='dark'?'#101923':'#e6eaf0'}
function toggleTheme(){setTheme(document.documentElement.dataset.t==='dark'?'soft':'dark')}
setTheme(localStorage.theme||'dark');

// ---------- الاتصال بالخادم ----------
async function api(p,body){
  let r;
  try{r=await fetch(p,{method:body?'POST':'GET',headers:Object.assign({'Content-Type':'application/json'},TOK?{Authorization:'Bearer '+TOK}:{}),body:body?JSON.stringify(body):undefined})}
  catch(e){online=false;net();throw new Error('تعذّر الاتصال بحاسوب المحل')}
  const j=await r.json().catch(()=>({}));
  if(r.status===401&&TOK&&p!=='/api/login'){sessionEnd();throw new Error(j.error||'انتهت الجلسة')}
  if(!r.ok)throw new Error(j.error||'حدث خطأ');
  return j;
}
function apply(s){
  ver=s.v;D.items=s.items;D.customers=s.customers;D.sales=s.sales;D.purchases=s.purchases||[];D.users=s.users||[];S=s.settings;me=s.me;ST=s.stats;
  s.sales.forEach(x=>SC[x.id]=x);
}
let rt;const rr=()=>{clearTimeout(rt);rt=setTimeout(()=>{if(!document.activeElement.matches('input,select,textarea'))render()},60)};
async function pull(hard){const s=await api('/api/state');if(s.v===ver&&!hard)return;apply(s);hard?render():rr()}
async function act(o,a){try{const r=await api('/api/op',{op:o,args:a||{}});await pull(true);return r}catch(e){err(e);throw e}}
function connect(){
  if(es)es.close();
  es=new EventSource('/api/events?t='+TOK);
  es.onopen=()=>{online=true;net();pull().catch(()=>{})};
  es.onmessage=()=>{pull().catch(()=>{})};
  es.onerror=()=>{online=false;net()};
}
function sessionEnd(){TOK='';localStorage.removeItem('tok');me=null;ver=-1;if(es){es.close();es=null}authView('login')}
function logout(){api('/api/logout',{}).catch(()=>{});sessionEnd()}

// ---------- الدخول ----------
function authView(mode,shop){
  const setup=mode==='setup';
  APP.innerHTML=`<div class=auth><div class=brandrow>${logo()}<div><div class=bn>${esc(shop||S.shop||'مخزني')}</div><div class=bs>نظام المبيعات والمخزون</div></div></div>
  <div class=card>${setup?'<p class=mu style="margin:0 0 4px">عند أول تشغيل، أنشئ حساب المدير.</p><label class=f>الاسم</label><input id=ln>':''}
  <label class=f ${setup?'':'style="margin-top:0"'}>اسم المستخدم</label><input id=lu autocomplete=username autocapitalize=off>
  <label class=f>كلمة المرور</label><input id=lp type=password autocomplete=current-password>
  ${setup?'<label class=f>سعر الدولار اليوم بالجنيه</label><input id=lr type=number inputmode=decimal placeholder="مثال: 11000">':''}
  ${setup?'<label class=f>اسم المحل (اختياري، يظهر في الفاتورة)</label><input id=ls>':''}
  <button class="btn p w" style="margin-top:16px" onclick="${setup?'doSetup()':'doLogin()'}">${setup?'إنشاء حساب المدير':'دخول'}</button></div></div>`;
  $('#lp').addEventListener('keydown',e=>{if(e.key==='Enter')setup?doSetup():doLogin()});
}
async function doLogin(){
  try{const r=await api('/api/login',{username:$('#lu').value,password:$('#lp').value});TOK=r.token;localStorage.tok=TOK;await pull(true);connect()}
  catch(e){err(e)}
}
async function doSetup(){
  try{const r=await api('/api/setup',{name:$('#ln').value,username:$('#lu').value,password:$('#lp').value,rate:$('#lr').value,shop:$('#ls').value});TOK=r.token;localStorage.tok=TOK;await pull(true);connect()}
  catch(e){err(e)}
}
(async()=>{
  try{
    const st=await fetch('/api/status').then(r=>r.json());
    S.shop=st.shop||'';
    if(st.setup)return authView('setup',st.shop);
    if(TOK){try{await pull(true);connect();return}catch(e){}}
    authView('login',st.shop);
  }catch(e){
    APP.innerHTML=`<div class=auth><div class="card c">تعذّر الاتصال بالبرنامج على حاسوب المحل.<br><small class=mu>تأكد من تشغيل البرنامج على الحاسوب ومن اتصالك بنفس الشبكة.</small><button class="btn w" style="margin-top:12px" onclick="location.reload()">إعادة المحاولة</button></div></div>`;
  }
})();

// ---------- الهيكل ----------
const TABS=[['dash','home','الرئيسية',0,0],['pos','pos','البيع',0,1],['rep','rep','المبيعات',0,1],['cust','cust','العملاء',0,1],['items','items','الأصناف',0,2],['buy','buy','المشتريات',1,2],['exp','exp','المنصرفات',1,3],['set','set','الإعدادات',1,3]];
const GL=['','العمليات','المخزون','الإدارة'],MAINNAV=['dash','items','pos','cust'];
const vis=()=>TABS.filter(t=>!t[3]||isAdmin());
const tabBy=k=>TABS.find(t=>t[0]==k);
function go(k){tab=k;render();scrollTo(0,0)}
function render(){
  if(!me)return;
  const v=vis(),cur=tabBy(tab)||[],low=D.items.filter(i=>i.qty!=null&&i.min>0&&i.qty<=i.min).length;
  const nv=t=>`<a class="nv${t[0]==tab?' on':''}" onclick="go('${t[0]}')">${ic(t[1])}<span>${t[2]}</span>${t[0]==='items'&&low?`<em class=cnt>${low}</em>`:''}</a>`;
  let side='',g=-1;v.forEach(t=>{if(t[4]!==g){g=t[4];if(g>0)side+=`<div class=gl>${GL[g]}</div>`}side+=nv(t)});
  const mn=k=>{const t=tabBy(k);return `<a class="${k=='pos'?'mid ':''}${k==tab?'on':''}" onclick="go('${k}')"><i>${ic(t[1])}</i><span>${t[2]}</span></a>`};
  const dateStr=new Date().toLocaleDateString('ar-EG-u-nu-latn',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  APP.innerHTML=`<div id=shell>
  <aside class=side><div class=brandrow>${logo()}${brandTxt()}</div>${side}<div class=sp></div>
   <div class=who><div class=av>${esc((me.name||'?').trim().charAt(0))}</div><div class=wn>${esc(me.name)}<small>${isAdmin()?'مدير':'بائع'}</small></div>
   <button class=ib onclick="toggleTheme()" title="تبديل المظهر">${ic('moon')}</button><button class=ib onclick="logout()" title="تسجيل الخروج">${ic('out')}</button></div></aside>
  <div class=main><div class=top>${logo().replace('class="logo"','class="mlogo"')}<div class=tt><h1>${cur[2]||''}</h1><div class=sub>${dateStr}</div></div><span class=pill id=net></span>
   ${isAdmin()?`<button class="pill num" onclick="rateAsk()" title="تعديل سعر الصرف">$1 = ${fmt(S.rate)} ج ${ic('edit',14)}</button>`:`<span class="pill num">$1 = ${fmt(S.rate)} ج</span>`}</div>${V[tab]()}</div>
  <nav class=bnav>${MAINNAV.map(mn).join('')}<a class="${MAINNAV.includes(tab)?'':'on'}" onclick="moreSheet()"><i>${ic('more')}</i><span>المزيد</span></a></nav></div>`;
  if(tab==='pos')drawCart();
  if(tab==='rep')loadRep();
  if(tab==='exp')loadExp();
  if(tab==='set')loadInfo();
  net();
}
function net(){const e=$('#net');if(e)e.innerHTML=`<i class="dot ${online?'':'off'}"></i><span class=nt>${online?'متصل':'غير متصل'}</span>`}
function sheet(title,h){$('#sheet').innerHTML=`<div class=sh onclick="event.stopPropagation()"><div class=shh><h3>${title}</h3><button class="btn g sm np" onclick="closeS()">${ic('x',18)}</button></div>${h}</div>`;$('#sheet').className='on'}
function closeS(){$('#sheet').className=''}
function moreSheet(){
  const rest=vis().filter(t=>!MAINNAV.includes(t[0]));
  sheet('المزيد',`${rest.length?`<div class=mg>${rest.map(t=>`<a onclick="closeS();go('${t[0]}')">${ic(t[1])}<span>${t[2]}</span></a>`).join('')}</div>`:''}
  <div class=list><div class=li onclick="toggleTheme()">${ic('moon')}<div class=a><b>تبديل المظهر</b></div></div>
  <div class=li onclick="closeS();logout()">${ic('out')}<div class=a><b>تسجيل الخروج</b><small>${esc(me.name)} — ${isAdmin()?'مدير':'بائع'}</small></div></div></div>`);
}
// بدائل لنوافذ prompt/confirm (غير مدعومة أو مشكلة داخل Electron)
let YC,AC;
function yn(msg,cb,label){YC=cb;sheet('تأكيد',`<p style="margin:6px 0 14px">${esc(msg).replace(/\n/g,'<br>')}</p><div class=row style="margin:0"><button class="btn p f1" onclick="closeS();YC()">${label||'نعم، متابعة'}</button><button class="btn f1" onclick="closeS()">إلغاء</button></div>`)}
function ask(title,label,type,cb){AC=cb;sheet(title,`<label class=f style="margin-top:0">${label}</label><input id=ask_v type="${type}" ${type==='number'?'inputmode=decimal':''} onkeydown="if(event.key==='Enter')askOk()"><button class="btn p w" style="margin-top:14px" onclick="askOk()">حفظ</button>`);setTimeout(()=>{const e=$('#ask_v');if(e)e.focus()},60)}
function askOk(){const v=$('#ask_v').value;closeS();AC(v)}
const tile=(t,v)=>`<div class="card tile"><small>${t}</small><b class=num><bdi dir="ltr">${fmt(v)}</bdi><span>ج</span></b></div>`;

function weekChart(){
  const w=ST.week||[0,0,0,0,0,0,0],mx=Math.max(...w,1),W=330,H=96,bw=34,gap=(W-7*bw)/6;
  return `<svg class=chart viewBox="0 0 ${W} ${H+22}" role="img" aria-label="مبيعات آخر 7 أيام">${w.map((v,i)=>{
    const h=Math.max(v/mx*H,v>0?5:2),x=(6-i)*(bw+gap),d=new Date();d.setDate(d.getDate()-(6-i));
    return `<rect class="cb${i===6?' on':''}" x="${x.toFixed(1)}" y="${(H-h).toFixed(1)}" width="${bw}" height="${h.toFixed(1)}" rx="7"><title>${fmt(v)} ج</title></rect><text class=cl2 x="${(x+bw/2).toFixed(1)}" y="${H+16}" text-anchor="middle">${d.toLocaleDateString('ar-EG-u-nu-latn',{weekday:'short'})}</text>`}).join('')}</svg>`;
}

// ---------- الشاشات ----------
const V={
dash:()=>{
  const low=D.items.filter(i=>i.qty!=null&&i.min>0&&i.qty<=i.min),adm=isAdmin();
  const hero=`<div class="card hero"><div class=hv><small>مبيعات اليوم</small><b class="big num"><bdi dir=ltr>${fmt(ST.today)}</bdi><span>ج</span></b><div class=hs>عدد الفواتير اليوم: <b class=num>${ST.todayCount||0}</b></div></div>${adm?`<div class=hc>${weekChart()}<div class=cap>مبيعات آخر 7 أيام</div></div>`:''}</div>`;
  const t=adm?[tile('مبيعات الشهر',ST.month),tile('منصرفات الشهر',ST.expMonth),tile('ديون العملاء',ST.debt),`<div class="card tile cl" onclick="rateAsk()"><small>سعر الدولار ${ic('edit',13)}</small><b class=num>${fmt(S.rate)}<span>ج</span></b></div>`]:[tile('ديون العملاء',ST.debt)];
  return `${hero}<div class=tiles>${t.join('')}</div>
  ${low.length?`<h3 class=sec>أصناف وصلت حد التنبيه</h3><div class=tbl>${itemHead}${low.slice(0,8).map(i=>itemRow(i,adm?`itemForm('${i.id}')`:'')).join('')}</div>`:''}
  <h3 class=sec>آخر الفواتير</h3>${D.sales.length?`<div class=list>${D.sales.slice(0,6).map(saleRow).join('')}</div>`:empty('لا توجد فواتير بعد. ابدأ من صفحة البيع.')}`;
},
pos:()=>`<div class=card><div class=sbox>${ic('search')}<input id=ps placeholder="ابحث عن صنف بالاسم أو الكود" oninput="posSearch()" autocomplete=off></div><div id=pr></div></div>
  <div id=cart></div>
  <div class=card><label class=f style="margin-top:0">العميل</label>
  <select id=pc onchange="P.c=this.value;calc()"><option value="">عميل نقدي</option>${D.customers.slice().sort(byName).map(c=>`<option value="${c.id}" ${P.c==c.id?'selected':''}>${esc(c.n)}</option>`).join('')}</select>
  <div class=row style="margin:0"><div class=f1><label class=f>الخصم (ج)</label><input id=pd type=number inputmode=decimal value="${esc(P.d)}" oninput="P.d=this.value;calc()"></div>
  <div class=f1><label class=f>المدفوع (ج)</label><input id=pp type=number inputmode=decimal placeholder="المبلغ كاملاً" value="${esc(P.p)}" oninput="P.p=this.value;calc()"></div></div></div>
  <div class=sum id=sum></div>`,
items:()=>`<div class=row><div class="sbox f1">${ic('search')}<input placeholder="ابحث بالاسم أو الكود" value="${esc(Q.i)}" oninput="Q.i=this.value;Q.n=60;itemsList()"></div>${isAdmin()?`<button class="btn p" onclick="itemForm()">${ic('plus',18)}صنف</button>`:''}</div>
  ${isAdmin()?`<div class="row tools"><button class="btn g" onclick="$('#xf').click()">${ic('down',18)}استيراد Excel</button><button class="btn g" onclick="exportItems()">${ic('up',18)}تصدير</button><button class="btn g" onclick="templateItems()">${ic('file',18)}نموذج</button><input id=xf type=file accept=".xlsx,.xls,.csv" hidden onchange="importItems(this)"></div>`:''}
  <div id=list>${itemList()}</div>`,
cust:()=>`<div class=row><div class="sbox f1">${ic('search')}<input placeholder="ابحث بالاسم أو الهاتف" value="${esc(Q.c)}" oninput="Q.c=this.value;custsList()"></div><button class="btn p" onclick="custForm()">${ic('plus',18)}عميل</button></div><div id=list>${custList()}</div>`,
buy:()=>{const it=D.items.find(x=>x.id===BI);return `<div class=card><div class=sbox>${ic('search')}<input id=bs placeholder="ابحث عن الصنف" oninput="buySearch()" autocomplete=off></div><div id=br></div>
  <div id=bch class="card" style="margin:10px 0 0;${it?'':'display:none'}">${it?`<b>${esc(it.n)}</b> <small class=mu>${cd(it.c)} — المخزون ${qv(it)}</small>`:''}</div>
  <div class=row style="margin:0"><div class=f1><label class=f>الكمية</label><input id=b_q type=number inputmode=decimal></div><div class=f1><label class=f>سعر الشراء ($)</label><input id=b_k type=number step=any inputmode=decimal></div></div>
  <label class=f>المورد</label><input id=b_s><button class="btn p w" style="margin-top:14px" onclick="doBuy()">تسجيل الشراء</button></div>
  <h3 class=sec>آخر المشتريات</h3>${D.purchases.length?`<div class=list>${D.purchases.map(p=>`<div class=li style="cursor:default"><div class=a><b>${esc(p.n)}</b><small><bdi>${dt(p.ts)}</bdi> ${esc(p.sup)}</small>${byTag(p.by)}</div><div class=q><span class="qv ok num">+${p.q}</span></div><div class="e num"><b>$${U(p.cost)}</b></div></div>`).join('')}</div>`:empty('لا توجد مشتريات مسجّلة.')}`},
rep:()=>`${isAdmin()?`<div class=row><input type=date value="${R.f}" onchange="R.f=this.value;loadRep()"><input type=date value="${R.t}" onchange="R.t=this.value;loadRep()"><button class="btn" onclick="exportSales()" title="تصدير Excel">${ic('up',18)}</button></div>${D.users.length?`<select style="margin-bottom:10px" onchange="Q.u=this.value;paintRep()"><option value="">كل المستخدمين</option>${D.users.map(u=>`<option value="${esc(u.name)}" ${Q.u===u.name?'selected':''}>${esc(u.name)}</option>`).join('')}</select>`:''}`:'<p class=mu style="margin:0 0 10px">مبيعات اليوم</p>'}<div id=rp>${repHtml()}</div>`,
exp:()=>`<div class=card><b>تسجيل منصرف جديد</b>
  <label class=f>النوع</label><select id=x_c>${EXPCATS.map(c=>`<option>${c}</option>`).join('')}</select>
  <label class=f>التفاصيل (اختياري)</label><input id=x_d>
  <div class=row style="margin:0"><div class=f1><label class=f>المبلغ (ج)</label><input id=x_v type=number inputmode=decimal></div><div class=f1><label class=f>التاريخ</label><input id=x_t type=date value="${today()}"></div></div>
  <button class="btn p w" style="margin-top:14px" onclick="addExp()">حفظ المنصرف</button></div>
  <h3 class=sec>السجل</h3><div class=row><input type=date value="${E.f}" onchange="E.f=this.value;loadExp()"><input type=date value="${E.t}" onchange="E.t=this.value;loadExp()"></div>${D.users.length?`<select style="margin-bottom:10px" onchange="E.u=this.value;paintExp()"><option value="">كل المستخدمين</option>${D.users.map(u=>`<option value="${esc(u.name)}" ${E.u===u.name?'selected':''}>${esc(u.name)}</option>`).join('')}</select>`:''}<div id=el>${expHtml()}</div>`,
set:()=>`<div class=card><label class=f style="margin-top:0">اسم المحل (يظهر في الفاتورة)</label><input id=s_s value="${esc(S.shop)}">
  <label class=f>عنوان المحل (يظهر في الفاتورة)</label><input id=s_a value="${esc(S.addr)}">
  <label class=f>رقم الهاتف (يظهر في الفاتورة)</label><input id=s_p type=tel value="${esc(S.phone)}">
  <label class=f>سعر الصرف (جنيه لكل 1 دولار)</label><input id=s_r type=number inputmode=decimal value="${S.rate}">
  <button class="btn p w" style="margin-top:14px" onclick="saveSet()">حفظ</button></div>
  <h3 class=sec>الاتصال بالهاتف</h3><div class=card id=info>${infoHtml()}</div>
  <h3 class=sec>المستخدمون</h3><div class=list>${D.users.map(u=>`<div class=li style="cursor:default"><div class=a><b>${esc(u.name)}</b><small>${cd(u.username)}</small></div><span class=badge>${u.role=='admin'?'مدير':'بائع'}</span><button class="btn g sm" onclick="passUser('${u.id}')" title="تغيير كلمة المرور">${ic('key',16)}</button>${u.id==me.id?'':`<button class="btn d sm" onclick="delUser('${u.id}')">${ic('trash',16)}</button>`}</div>`).join('')}</div>
  <div class=card style="margin-top:12px"><b>إضافة مستخدم</b>
  <label class=f>الاسم</label><input id=u_n><label class=f>اسم المستخدم (بحروف إنجليزية)</label><input id=u_u autocapitalize=off>
  <label class=f>كلمة المرور (4 أحرف على الأقل)</label><input id=u_p type=password><label class=f>الصلاحية</label>
  <select id=u_r><option value=seller>بائع</option><option value=admin>مدير</option></select>
  <button class="btn p w" style="margin-top:14px" onclick="addUser()">إضافة</button></div>
  <h3 class=sec>النسخ الاحتياطي</h3><div class=card><p class=mu style="margin:0 0 10px">البيانات محفوظة على هذا الحاسوب فقط. يحفظ البرنامج نسخة احتياطية تلقائية كل يوم، ويُنصح بنسخ ملف احتياطي إلى ذاكرة فلاش من وقت لآخر.</p>
  <div class="row tools" style="margin:0"><button class="btn" onclick="location.href='/api/backup?t='+TOK">${ic('up',18)}تنزيل نسخة</button><button class="btn" onclick="$('#rf').click()">${ic('down',18)}استرجاع نسخة</button><input id=rf type=file accept=".json" hidden onchange="restoreBackup(this)"></div></div>`
};

// ---------- الأصناف ----------
function itemList(){
  const s=(Q.i||'').toLowerCase(),all=D.items.filter(i=>((i.n||'')+' '+(i.c||'')).toLowerCase().includes(s)).sort(byName),n=Q.n||60;
  if(!all.length)return empty(D.items.length?'لا توجد نتائج مطابقة للبحث.':'لا توجد أصناف بعد. أضف صنفاً أو استورد ملف Excel.');
  return `<div class=tbl>${itemHead}${all.slice(0,n).map(i=>itemRow(i,isAdmin()?`itemForm('${i.id}')`:'')).join('')}</div>
  ${all.length>n?`<button class="btn g w" style="margin-top:10px" onclick="Q.n+=60;itemsList()">عرض المزيد (${all.length-n})</button>`:''}<p class="c mu num">${all.length} صنف</p>`;
}
function itemsList(){const e=$('#list');if(e)e.innerHTML=itemList()}
function itemForm(id){
  const i=D.items.find(x=>x.id===id)||{};
  sheet(id?'تعديل صنف':'صنف جديد',`<label class=f style="margin-top:0">الاسم</label><input id=f_n value="${esc(i.n)}">
  <label class=f>الكود</label><input id=f_c value="${esc(i.c)}">
  <div class=row style="margin:0"><div class=f1><label class=f>سعر البيع ($)</label><input id=f_p type=number step=any inputmode=decimal value="${i.p??''}"></div><div class=f1><label class=f>سعر الشراء ($)</label><input id=f_k type=number step=any inputmode=decimal value="${i.cost??''}"></div></div>
  <div class=row style="margin:0"><div class=f1><label class=f>الكمية</label><input id=f_q type=number inputmode=decimal placeholder="اتركه فارغاً لعدم متابعة الكمية" value="${i.qty??''}"></div><div class=f1><label class=f>حد التنبيه</label><input id=f_m type=number inputmode=decimal value="${i.min??''}"></div></div>
  <div class=row style="margin:16px 0 0"><button class="btn p f1" onclick="saveItem('${id||''}')">حفظ</button>${id?`<button class="btn d" onclick="delItem('${id}')">${ic('trash',18)}</button>`:''}</div>`);
}
function saveItem(id){
  const d={n:$('#f_n').value.trim(),c:$('#f_c').value.trim(),qty:$('#f_q').value===''?null:+$('#f_q').value,min:+$('#f_m').value||0,cost:+$('#f_k').value||0,p:+$('#f_p').value||0};
  if(!d.n)return toast('أدخل اسم الصنف',1);
  act('item.save',{id,data:d}).then(()=>{closeS();toast('تم الحفظ')}).catch(()=>{});
}
function delItem(id){const i=D.items.find(x=>x.id===id);yn('حذف الصنف "'+(i?i.n:'')+'"؟',()=>act('item.del',{id}).then(()=>toast('تم الحذف')).catch(()=>{}),'نعم، احذف')}

// ---------- استيراد / تصدير Excel ----------
const HEAD=['الصنف','الكود','السعر بالدولار','الكمية','سعر الشراء','حد التنبيه'];
const KEYS={n:['الصنف','اسم الصنف','الاسم','اسم','name','item'],c:['الكود','كود','code'],p:['السعر بالدولار','السعر','سعر البيع','price','usd'],
            q:['الكمية','كمية','qty','quantity'],k:['سعر الشراء','سعر الشراء بالدولار','cost'],m:['حد التنبيه','min']};
const pick=(r,ks)=>{for(const h in r){if(ks.includes(String(h).trim().toLowerCase()))return r[h]}};
const num=v=>{const x=parseFloat(String(v??'').replace(/,/g,'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)));return isNaN(x)?undefined:x};
function needXlsx(){if(typeof XLSX==='undefined'){toast('مكتبة Excel غير متوفرة في هذه النسخة',1);return true}}
function saveXlsx(rows,name,sheetName,w){
  if(needXlsx())return;
  const ws=XLSX.utils.aoa_to_sheet(rows);ws['!cols']=(w||[32,16,16,10,14,12]).map(x=>({wch:x}));
  const wb=XLSX.utils.book_new();wb.Workbook={Views:[{RTL:true}]};XLSX.utils.book_append_sheet(wb,ws,sheetName||'الأصناف');XLSX.writeFile(wb,name);
}
function exportItems(){saveXlsx([HEAD,...D.items.slice().sort(byName).map(i=>[i.n,i.c||'',i.p||0,i.qty==null?'':i.qty,i.cost||0,i.min||0])],'الأصناف-'+today()+'.xlsx')}
function templateItems(){saveXlsx([HEAD],'نموذج-الأصناف.xlsx')}
function exportSales(){
  saveXlsx([['الرقم','التاريخ','العميل','الإجمالي (ج)','المدفوع (ج)','المتبقي (ج)','البائع'],...repSales().map(s=>[s.no,dtm(s.ts),s.custName,Math.round(s.total*s.rate),Math.round(s.paid*s.rate),Math.round((s.total-s.paid)*s.rate),s.by])],'المبيعات-'+R.f+'.xlsx','المبيعات',[10,18,20,14,14,14,14]);
}
const nm=s=>String(s??'').replace(/\s+/g,' ').trim();
async function importItems(inp){
  const file=inp.files[0];inp.value='';if(!file||needXlsx())return;
  try{
    const wb=XLSX.read(await file.arrayBuffer(),{type:'array'});
    const rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:''});
    const byKey={},byName={};
    D.items.forEach(i=>{byKey[nm(i.n).toLowerCase()+'|'+(i.c||'').toLowerCase()]=i.id;const k=nm(i.n).toLowerCase();(byName[k]=byName[k]||[]).push(i.id)});
    const ops=[];let add=0,upd=0;
    rows.forEach(r=>{
      const n=nm(pick(r,KEYS.n)),c=nm(pick(r,KEYS.c));if(!n)return;
      const d={n};if(c)d.c=c;
      [['p','p'],['q','qty'],['k','cost'],['m','min']].forEach(([k,fld])=>{const v=num(pick(r,KEYS[k]));if(v!==undefined)d[fld]=v});
      const key=n.toLowerCase()+'|'+c.toLowerCase(),nk=n.toLowerCase();
      let id=byKey[key];
      if(!id&&byName[nk]&&byName[nk].length===1)id=byName[nk][0];
      if(id){ops.push([id,d]);upd++}
      else{id=rid();byKey[key]=id;ops.push([id,Object.assign({c:''},d)]);add++}
    });
    if(!ops.length)return toast('لم يتم العثور على أصناف في الملف. تأكد من عناوين الأعمدة: الصنف، الكود، السعر بالدولار، الكمية',1);
    yn(`أصناف جديدة: ${add}\nأصناف موجودة سيتم تحديثها: ${upd}\n\nسيتم استبدال السعر والكمية بالقيم الموجودة في الملف.`,()=>
      act('items.import',{rows:ops}).then(r=>toast(`تم الاستيراد: ${r.add} جديد، ${r.upd} محدّث`)).catch(()=>{}),'استيراد');
  }catch(e){toast('تعذّر قراءة الملف: '+e.message,1)}
}

// ---------- البيع ----------
function posSearch(){
  const s=$('#ps').value.toLowerCase().trim();
  $('#pr').innerHTML=s?(()=>{const r=D.items.filter(i=>((i.n||'')+' '+(i.c||'')).toLowerCase().includes(s)).slice(0,8);
    return r.length?`<div class=tbl style="margin-top:10px">${itemHead}${r.map(i=>itemRow(i,`addCart('${i.id}')`)).join('')}</div>`:'<p class="mu c">لا يوجد صنف بهذا الاسم</p>'})():'';
}
function addCart(id){
  const i=D.items.find(x=>x.id===id),l=cart.find(x=>x.id===id);
  if(l)l.q++;else cart.push({id,n:i.n,q:1,p:i.p||0});
  $('#ps').value='';$('#pr').innerHTML='';drawCart();$('#ps').focus();
}
function chg(i,d){cart[i].q+=d;if(cart[i].q<=0)cart.splice(i,1);drawCart()}
function drawCart(){
  $('#cart').innerHTML=cart.length?`<div class=list style="margin-bottom:12px">${cart.map((l,i)=>`<div class=li style="cursor:default"><div class=a><b>${esc(l.n)}</b><small class=num>${sdg(l.p)} ج للوحدة</small></div>
  <div class=step><button onclick="chg(${i},-1)">${ic('minus',16)}</button><span class=num>${l.q}</span><button onclick="chg(${i},1)">${ic('plus',16)}</button></div>
  <b class="m num" style="min-width:74px;text-align:start">${sdg(l.p*l.q)}</b></div>`).join('')}</div>`:empty('الفاتورة فارغة. ابحث عن صنف وأضفه.');
  calc();
}
function tot(){
  const sub=cart.reduce((a,l)=>a+l.q*l.p,0)*S.rate,d=+P.d||0,total=Math.max(sub-d,0),paid=P.p===''?total:Math.min(Math.max(+P.p||0,0),total);
  return{d,total,paid,rest:total-paid};
}
function calc(){
  const t=tot(),e=$('#sum');if(!e)return;
  e.innerHTML=`<div><small>الإجمالي</small><b class="m num">${fmt(t.total)} ج</b>${t.rest>0.5?`<small class=rd>دين ${fmt(t.rest)} ج</small>`:`<small class=num>$${U(t.total/S.rate)}</small>`}</div>
  <button class="btn p" style="padding:12px 24px" onclick="saveSale()" ${cart.length&&!saving?'':'disabled'}>حفظ الفاتورة</button>`;
}
function saveSale(){
  if(!cart.length||saving)return;
  const t=tot();
  if(t.rest/S.rate>0.001&&!P.c)return toast('اختر عميلاً لتسجيل المبلغ المتبقي كدين',1);
  const over=cart.filter(l=>{const it=D.items.find(x=>x.id===l.id);return it&&it.qty!=null&&l.q>it.qty}).map(l=>l.n);
  if(over.length)yn('الكمية المطلوبة أكبر من المخزون في:\n'+over.join('، ')+'\n\nمتابعة؟',doSale);else doSale();
}
async function doSale(){
  saving=true;calc();
  try{
    const r=await act('sale.create',{lines:cart.map(l=>({id:l.id,q:l.q})),disc:P.d,paid:P.p,cust:P.c});
    SC[r.sale.id]=r.sale;cart=[];P={c:'',d:'',p:''};saving=false;render();toast('تم حفظ الفاتورة');invoiceView(r.sale.id);
  }catch(e){saving=false;calc()}
}
const byTag=n=>n?`<small class=by>${ic('cust',13)}${esc(n)}</small>`:'';
const saleRow=s=>`<div class=li onclick="invoiceView('${s.id}')"><div class=a><b>${esc(s.custName)}</b><small class=num><bdi>#${s.no}</bdi> — <bdi>${dtm(s.ts)}</bdi></small>${byTag(s.by)}</div>${s.total-s.paid>0.001?'<span class="badge low">دين</span>':''}<div class="e num"><b>${fmt(s.total*s.rate)} ج</b></div></div>`;
function invoiceView(id){
  const s=SC[id];if(!s)return;
  const sub=s.total+(s.disc||0),rest=s.total-s.paid;
  sheet('الفاتورة',`<div class=inv>
  <div class=ih><div class=sn>${esc(S.shop||'')}</div>${S.addr?`<div class=ss>${esc(S.addr)}</div>`:''}${S.phone?`<div class="ss num">هاتف: ${cd(S.phone)}</div>`:''}</div>
  <div class=it>فاتورة مبيعات</div>
  <div class=im><div><span>رقم الفاتورة</span><b class=num><bdi>${s.no}</bdi></b></div><div><span>التاريخ</span><b class=num><bdi>${dtm(s.ts)}</bdi></b></div>
  <div><span>العميل</span><b>${esc(s.custName)}</b></div><div><span>البائع</span><b>${esc(s.by)}</b></div></div>
  <table class=itb><thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${s.lines.map((l,i)=>`<tr class=num><td>${i+1}</td><td class=nm>${esc(l.n)}</td><td>${l.q}</td><td>${fmt(l.p*s.rate)}</td><td>${fmt(l.p*l.q*s.rate)}</td></tr>`).join('')}</tbody></table>
  <div class="tot num"><div><span>المجموع</span><span>${fmt(sub*s.rate)} ج</span></div>${s.disc?`<div><span>الخصم</span><span>${fmt(s.disc*s.rate)} ج</span></div>`:''}
  <div class=big><span>الإجمالي المستحق</span><span>${fmt(s.total*s.rate)} ج</span></div><div><span>المدفوع</span><span>${fmt(s.paid*s.rate)} ج</span></div>
  ${rest*s.rate>0.5?`<div class=due><span>المتبقي (دين)</span><span>${fmt(rest*s.rate)} ج</span></div>`:''}</div>
  <div class=if>شكراً لتعاملكم معنا</div></div>
  <div class="row np" style="margin:14px 0 0"><button class="btn p f1" onclick="printInv('a')">${ic('print',18)}طباعة A4</button><button class="btn f1" onclick="printInv('r')">${ic('print',18)}طباعة إيصال</button></div>
  ${isAdmin()?`<div class=np style="margin-top:8px"><button class="btn d w" onclick="voidSale('${id}')">إلغاء الفاتورة</button></div>`:''}`);
}
function printInv(mode){
  const st=document.createElement('style');
  st.textContent=mode==='r'?'@page{size:80mm auto;margin:2mm}':'@page{size:A4;margin:14mm}';
  document.head.appendChild(st);document.body.classList.toggle('rcpt',mode==='r');
  const done=()=>{st.remove();document.body.classList.remove('rcpt');removeEventListener('afterprint',done)};
  addEventListener('afterprint',done);setTimeout(()=>window.print(),80);
}
function voidSale(id){yn('إلغاء الفاتورة وإرجاع الكميات للمخزون؟',()=>act('sale.void',{id}).then(()=>toast('تم إلغاء الفاتورة')).catch(()=>{}),'نعم، ألغِ')}

// ---------- العملاء ----------
function custList(){
  const s=(Q.c||'').toLowerCase(),r=D.customers.filter(c=>((c.n||'')+' '+(c.ph||'')).toLowerCase().includes(s)).sort(byName);
  return r.length?`<div class=list>${r.map(c=>`<div class=li onclick="custView('${c.id}')"><div class=a><b>${esc(c.n)}</b><small class=num>${cd(c.ph)||'بدون هاتف'}</small></div>
  <div class="e num"><b style="${(c.bal||0)>0.001?'color:var(--rd)':'color:var(--mu)'}">${fmt((c.bal||0)*S.rate)} ج</b><small>${(c.bal||0)>0.001?'دين':'لا دين'}</small></div></div>`).join('')}</div>`:empty(D.customers.length?'لا توجد نتائج.':'لا يوجد عملاء بعد.');
}
function custsList(){const e=$('#list');if(e)e.innerHTML=custList()}
function custForm(){sheet('عميل جديد',`<label class=f style="margin-top:0">الاسم</label><input id=f_n><label class=f>الهاتف</label><input id=f_h type=tel><button class="btn p w" style="margin-top:16px" onclick="saveCust()">حفظ</button>`)}
function saveCust(){const n=$('#f_n').value.trim();if(!n)return toast('أدخل اسم العميل',1);act('cust.save',{n,ph:$('#f_h').value.trim()}).then(()=>{closeS();toast('تمت الإضافة')}).catch(()=>{})}
async function custView(id){
  const c=D.customers.find(x=>x.id===id);if(!c)return;
  let r;try{r=await api('/api/cust/'+id)}catch(e){return err(e)}
  r.sales.forEach(s=>SC[s.id]=s);
  const ev=[...r.sales.map(s=>({ts:s.ts,t:'دين فاتورة <bdi>#'+s.no+'</bdi>',v:(s.total-s.paid)*s.rate,sid:s.id})),...r.payments.map(p=>({ts:p.ts,t:'دفعة',v:-p.sdg,by:p.by}))].sort((a,b)=>b.ts-a.ts);
  sheet(esc(c.n),`<div class=card style="margin-top:6px"><small class=mu>الدين الحالي</small><br><b class="m num" style="font-size:24px">${fmt((c.bal||0)*S.rate)} ج</b>${c.ph?`<br><small class="mu num">${cd(c.ph)}</small>`:''}</div>
  <div class=row><button class="btn p f1" onclick="pay('${id}')">${ic('plus',18)}تسجيل دفعة</button>${isAdmin()?`<button class="btn d" onclick="delCust('${id}')">${ic('trash',18)}</button>`:''}</div>
  ${ev.length?`<div class=list>${ev.map(e=>`<div class=li ${e.sid?`onclick="invoiceView('${e.sid}')"`:'style="cursor:default"'}><div class=a><b>${e.t}</b><small class=num>${dt(e.ts)}</small>${byTag(e.by)}</div><b class="num" style="color:${e.v<0?'var(--gr)':'var(--rd)'}">${e.v<0?'−':'+'}${fmt(Math.abs(e.v))}</b></div>`).join('')}</div>`:''}`);
}
function pay(id){ask('تسجيل دفعة','المبلغ المدفوع بالجنيه','number',v=>{v=+v;if(!(v>0))return toast('أدخل مبلغاً صحيحاً',1);act('cust.pay',{id,sdg:v}).then(()=>toast('تم تسجيل الدفعة')).catch(()=>{})})}
function delCust(id){yn('حذف العميل؟',()=>act('cust.del',{id}).then(()=>{closeS();toast('تم الحذف')}).catch(()=>{}),'نعم، احذف')}

// ---------- الشراء ----------
function buySearch(){
  const s=$('#bs').value.toLowerCase().trim();
  $('#br').innerHTML=s?`<div class=list style="margin-top:10px">${D.items.filter(i=>((i.n||'')+' '+(i.c||'')).toLowerCase().includes(s)).slice(0,6).map(i=>`<div class=li onclick="pickBuy('${i.id}')"><div class=a><b>${esc(i.n)}</b><small>${cd(i.c)}</small></div>${qb(i)}</div>`).join('')}</div>`:'';
}
function pickBuy(id){
  BI=id;const it=D.items.find(x=>x.id===id);$('#bs').value='';$('#br').innerHTML='';
  const e=$('#bch');e.style.display='block';e.innerHTML=`<b>${esc(it.n)}</b> <small class=mu>${cd(it.c)} — المخزون ${qv(it)}</small>`;
  if(it.cost)$('#b_k').value=it.cost;$('#b_q').focus();
}
function doBuy(){
  const q=+$('#b_q').value,k=+$('#b_k').value||0;
  if(!BI)return toast('اختر الصنف أولاً',1);if(!(q>0))return toast('أدخل الكمية',1);
  act('buy.create',{item:BI,q,cost:k,sup:$('#b_s').value.trim()}).then(()=>{BI='';render();toast('تم تسجيل الشراء')}).catch(()=>{});
}

// ---------- سجل المبيعات والتقارير ----------
async function loadRep(){
  if(!isAdmin())R={f:today(),t:today()};
  const k=R.f+'|'+R.t+'|'+ver;
  if(RS.k===k){paintRep();return}
  try{const r=await api('/api/sales?f='+R.f+'&t='+R.t);RS={k,list:r.sales,exp:r.expenses||[]};r.sales.forEach(s=>SC[s.id]=s);paintRep()}catch(e){err(e)}
}
function paintRep(){const e=$('#rp');if(e)e.innerHTML=repHtml()}
function repRows(){
  const q=(Q.r||'').toLowerCase().trim(),ss=repSales().filter(s=>!q||(s.no+' '+s.custName).toLowerCase().includes(q));
  return ss.length?`<div class=list>${ss.map(saleRow).join('')}</div>`:empty('لا توجد فواتير.');
}
function repSales(){return Q.u?RS.list.filter(s=>s.by===Q.u):RS.list}
function repHtml(){
  const ss=repSales();let tt=0,pd=0,pr=0,top={},nocost=new Set();
  ss.forEach(s=>{tt+=s.total*s.rate;pd+=s.paid*s.rate;if(isAdmin())s.lines.forEach(l=>{if(!l.cost)nocost.add(l.n)});if(isAdmin())pr+=(s.lines.reduce((a,l)=>a+l.q*(l.p-(l.cost||0)),0)-(s.disc||0))*s.rate;s.lines.forEach(l=>top[l.n]=(top[l.n]||0)+l.q)});
  const ex=(RS.exp||[]).filter(e=>!Q.u||e.by===Q.u).reduce((a,e)=>a+e.sdg,0);
  const tiles=isAdmin()?[tile('المبيعات',tt),tile('المحصّل',pd),tile('المنصرفات',ex),tile('ديون الفترة',tt-pd),tile('ربح المبيعات',pr),tile('صافي الربح',pr-ex)]:[tile('المبيعات',tt),tile('المحصّل',pd),tile('ديون اليوم',tt-pd)];
  const tp=Object.entries(top).sort((a,b)=>b[1]-a[1]).slice(0,8);
  return `<div class=tiles>${tiles.join('')}</div>
  ${isAdmin()&&nocost.size?`<p class=mu style="font-size:13px;margin:8px 2px 0">تنبيه: الربح غير دقيق لأن ${nocost.size} صنفاً مباعاً لم يُدخل له سعر شراء.</p>`:''}
  ${tp.length&&isAdmin()?`<h3 class=sec>الأكثر مبيعاً</h3><div class=list>${tp.map(([n,q])=>`<div class=li style="cursor:default"><div class=a><b>${esc(n)}</b></div><div class=q><span class="qv ok num">${q}</span></div></div>`).join('')}</div>`:''}
  <h3 class=sec>الفواتير <span class="num">(${ss.length})</span></h3>
  <div class=sbox style="margin-bottom:10px">${ic('search')}<input placeholder="ابحث برقم الفاتورة أو اسم العميل" value="${esc(Q.r)}" oninput="Q.r=this.value;const e=$('#rl');if(e)e.innerHTML=repRows()"></div><div id=rl>${repRows()}</div>`;
}
// المنصرفات
const EXPCATS=['إيجار','كهرباء ومياه','مرتبات','نقل وشحن','وجبات','صيانة','أخرى'];
async function loadExp(){
  const k=E.f+'|'+E.t+'|'+ver;
  if(ES.k===k){paintExp();return}
  try{const r=await api('/api/expenses?f='+E.f+'&t='+E.t);ES={k,list:r.expenses};paintExp()}catch(e){err(e)}
}
function paintExp(){const e=$('#el');if(e)e.innerHTML=expHtml()}
function expHtml(){
  const l=E.u?ES.list.filter(e=>e.by===E.u):ES.list,tt=l.reduce((a,e)=>a+e.sdg,0),by={};l.forEach(e=>by[e.cat]=(by[e.cat]||0)+e.sdg);
  return `<div class=tiles>${tile('إجمالي المنصرفات',tt)}<div class="card tile"><small>عدد العمليات</small><b class=num>${l.length}</b></div></div>
  ${Object.keys(by).length?`<div class=card style="margin-top:10px">${Object.entries(by).sort((a,b)=>b[1]-a[1]).map(([c,v])=>`<div class=row style="margin:4px 0"><span class=f1>${esc(c)}</span><b class="m num">${fmt(v)} ج</b></div>`).join('')}</div>`:''}
  <div style="margin-top:10px">${l.length?`<div class=list>${l.map(e=>`<div class=li style="cursor:default"><div class=a><b>${esc(e.desc||e.cat)}</b><small><bdi>${dt(e.ts)}</bdi> — ${esc(e.cat)}</small>${byTag(e.by)}</div><b class=num style="color:var(--rd)">${fmt(e.sdg)} ج</b><button class="btn d sm" onclick="delExp('${e.id}')">${ic('trash',16)}</button></div>`).join('')}</div>`:empty('لا توجد منصرفات في هذه الفترة.')}</div>`;
}
function addExp(){
  const v=+$('#x_v').value;if(!(v>0))return toast('أدخل المبلغ',1);
  act('exp.add',{cat:$('#x_c').value,desc:$('#x_d').value.trim(),sdg:v,date:$('#x_t').value}).then(()=>toast('تم حفظ المنصرف')).catch(()=>{});
}
function delExp(id){yn('حذف هذا المنصرف؟',()=>act('exp.del',{id}).then(()=>toast('تم الحذف')).catch(()=>{}),'نعم، احذف')}

// ---------- الإعدادات ----------
function infoHtml(){
  if(!INFO)return '<span class=mu>جاري التحميل...</span>';
  return `<p style="margin:0 0 8px">افتح أحد هذه العناوين في متصفح الهاتف، بشرط أن يكون متصلاً بنفس شبكة الواي فاي:</p>
  ${INFO.addresses.length?INFO.addresses.map(a=>`<div class="pill num" style="display:block;margin:6px 0;color:var(--tx);direction:ltr;text-align:center;font-size:15px">${esc(a)}</div>`).join(''):'<p class=rd>لا يوجد اتصال بالشبكة. وصّل الحاسوب بالراوتر.</p>'}
  <p class=mu style="margin:8px 0 0;font-size:13px">مكان حفظ البيانات: <bdi dir=ltr>${esc(INFO.dataDir)}</bdi></p>`;
}
async function loadInfo(){if(!isAdmin())return;if(!INFO){try{INFO=await api('/api/info')}catch(e){return}}const e=$('#info');if(e)e.innerHTML=infoHtml()}
function rateAsk(){if(!isAdmin())return;ask('سعر الصرف','كم جنيهاً لكل 1 دولار؟','number',v=>{v=+v;if(!(v>0))return toast('أدخل رقماً صحيحاً',1);act('settings.save',{rate:v,shop:S.shop,phone:S.phone,addr:S.addr}).then(()=>toast('تم تحديث جميع الأسعار')).catch(()=>{})})}
function saveSet(){const r=+$('#s_r').value;if(!(r>0))return toast('سعر الصرف غير صحيح',1);act('settings.save',{rate:r,shop:$('#s_s').value.trim(),phone:$('#s_p').value.trim(),addr:$('#s_a').value.trim()}).then(()=>toast('تم الحفظ')).catch(()=>{})}
function addUser(){
  const n=$('#u_n').value.trim(),u=$('#u_u').value.trim().toLowerCase(),p=$('#u_p').value;
  if(!n||!u||p.length<4)return toast('أكمل البيانات (كلمة المرور 4 أحرف على الأقل)',1);
  act('user.add',{name:n,username:u,password:p,role:$('#u_r').value}).then(()=>{toast('تمت إضافة المستخدم');['u_n','u_u','u_p'].forEach(k=>{const e=$('#'+k);if(e)e.value=''})}).catch(()=>{});
}
function delUser(id){yn('حذف هذا المستخدم؟',()=>act('user.del',{id}).then(()=>toast('تم الحذف')).catch(()=>{}),'نعم')}
function passUser(id){ask('كلمة مرور جديدة','كلمة المرور (4 أحرف على الأقل)','password',v=>{if(v.length<4)return toast('كلمة المرور قصيرة',1);act('user.pass',{id,password:v}).then(()=>toast('تم تغيير كلمة المرور')).catch(()=>{})})}
function restoreBackup(inp){
  const f=inp.files[0];inp.value='';if(!f)return;
  const rd=new FileReader();
  rd.onload=()=>{let j;try{j=JSON.parse(rd.result)}catch(e){return toast('الملف غير صالح',1)}
    yn('سيؤدي الاسترجاع إلى استبدال جميع البيانات الحالية بالنسخة المختارة، وتسجيل خروج جميع المستخدمين. هل تريد المتابعة؟',async()=>{
      try{await api('/api/restore',j);toast('تم الاسترجاع. سجّل الدخول مرة أخرى.');sessionEnd()}catch(e){err(e)}},'نعم، استرجع')};
  rd.readAsText(f);
}
