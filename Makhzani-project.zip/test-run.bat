@echo off
chcp 65001 >nul
title Test run
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Download it from https://nodejs.org
  pause
  exit /b 1
)
if not exist node_modules call npm install
call npm start
