'use strict';
const { app, BrowserWindow, Tray, Menu, nativeImage, dialog, shell, clipboard } = require('electron');
const path = require('path'), fs = require('fs');
const { createServer } = require('./server');

const NAME = 'مخزني';
const hidden = process.argv.includes('--hidden');
let win = null, tray = null, srv = null, quitting = false, notified = false;

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => showWin());
  app.whenReady().then(start).catch(e => { dialog.showErrorBox(NAME, 'تعذّر تشغيل البرنامج:\n' + e.message); app.quit(); });
}

const cfgFile = () => path.join(app.getPath('userData'), 'config.json');
const readCfg = () => { try { return JSON.parse(fs.readFileSync(cfgFile(), 'utf8')); } catch (e) { return {}; } };
const writeCfg = c => { try { fs.writeFileSync(cfgFile(), JSON.stringify(c)); } catch (e) {} };

async function start() {
  const dataDir = path.join(app.getPath('userData'), 'data');
  srv = createServer({ dataDir, publicDir: path.join(__dirname, 'public'), shopName: '' });
  try { await srv.listen(3000); }
  catch (e) { dialog.showErrorBox(NAME, 'تعذّر فتح المنفذ 3000. غالباً أن البرنامج يعمل مسبقاً أو أن برنامجاً آخر يستخدم هذا المنفذ.\n' + e.message); app.quit(); return; }

  // تشغيل مع الويندوز (يتفعّل تلقائي أول مرة، وتقدر توقفو من أيقونة البرنامج جنب الساعة)
  const cfg = readCfg();
  if (cfg.autostart === undefined) { cfg.autostart = true; writeCfg(cfg); }
  applyAutostart(cfg.autostart);

  makeWindow();
  makeTray();
}

function applyAutostart(on) {
  if (!app.isPackaged) return;
  app.setLoginItemSettings({ openAtLogin: !!on, args: ['--hidden'] });
}

function makeWindow() {
  win = new BrowserWindow({
    width: 1200, height: 780, minWidth: 420, minHeight: 600, title: NAME, show: !hidden,
    backgroundColor: '#1c242e', autoHideMenuBar: true,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.removeMenu();
  win.loadURL('http://127.0.0.1:' + srv.getPort());
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.on('page-title-updated', e => e.preventDefault());
  win.on('close', e => {
    if (quitting) return;
    e.preventDefault(); win.hide();
    if (!notified && tray) { notified = true; try { tray.displayBalloon({ title: NAME, content: 'البرنامج يعمل في الخلفية ليبقى الهاتف متصلاً. للخروج الكامل: انقر بزر الفأرة الأيمن على الأيقونة ثم اختر خروج.' }); } catch (e) {} }
  });
}

function showWin() { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); }

function makeTray() {
  const img = nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png')).resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip(NAME);
  tray.on('click', showWin);
  const rebuild = () => {
    const cfg = readCfg(), addrs = srv.addresses();
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'فتح البرنامج', click: showWin },
      { type: 'separator' },
      { label: 'عنوان الهاتف (انقر للنسخ):', enabled: false },
      ...(addrs.length ? addrs.map(a => ({ label: '   ' + a, click: () => clipboard.writeText(a) })) : [{ label: '   لا يوجد اتصال بالشبكة', enabled: false }]),
      { type: 'separator' },
      { label: 'تشغيل مع الويندوز', type: 'checkbox', checked: !!cfg.autostart, click: m => { cfg.autostart = m.checked; writeCfg(cfg); applyAutostart(m.checked); } },
      { label: 'فتح مجلد البيانات', click: () => shell.openPath(path.join(app.getPath('userData'), 'data')) },
      { type: 'separator' },
      { label: 'خروج', click: () => { quitting = true; app.quit(); } }
    ]));
  };
  rebuild(); setInterval(rebuild, 60000);
  tray.on('right-click', rebuild);
}

app.on('before-quit', () => { quitting = true; if (srv) { srv.flush(); srv.close(); } });
app.on('window-all-closed', () => { /* يفضل شغّال في الخلفية */ });
