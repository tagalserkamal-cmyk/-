'use strict';
// خادم محلي بدون أي مكتبات خارجية: يخزّن البيانات في ملف db.json داخل جهاز المحل
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), zlib = require('zlib'), os = require('os');

class E extends Error { constructor(m, c) { super(m); this.c = c || 400; } }
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const rid = () => crypto.randomBytes(5).toString('hex');
const num = (v, d = 0) => { v = Number(v); return Number.isFinite(v) ? v : d; };
const str = (v, n = 200) => String(v == null ? '' : v).slice(0, n);
const r3 = v => Math.round(v * 1000) / 1000;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2', '.woff': 'font/woff' };
const ADMIN_OPS = new Set(['item.save', 'item.del', 'items.import', 'sale.void', 'exp.add', 'exp.del', 'cust.del', 'buy.create', 'settings.save', 'user.add', 'user.del', 'user.pass']);

function createServer(opts) {
  const DATA = opts.dataDir, PUB = path.resolve(opts.publicDir), FILE = path.join(DATA, 'db.json'), BK = path.join(DATA, 'backups');
  fs.mkdirSync(BK, { recursive: true });

  // ---------- التخزين ----------
  const tryRead = f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } };
  function load() {
    const base = { v: 1, seq: 1000, items: {}, customers: {}, sales: [], purchases: [], payments: [], expenses: [], users: [], settings: { rate: 11000, shop: opts.shopName || '', phone: '' }, sessions: {} };
    if (!fs.existsSync(FILE)) {
      return base;
    }
    let d = tryRead(FILE);
    if (!d) {
      try { fs.copyFileSync(FILE, FILE + '.corrupt-' + Date.now()); } catch (e) {}
      const bs = fs.readdirSync(BK).filter(f => f.endsWith('.json')).sort().reverse();
      for (const f of bs) { d = tryRead(path.join(BK, f)); if (d) { console.log('استرجاع من النسخة الاحتياطية', f); break; } }
    }
    return Object.assign(base, d || {});
  }
  let db = load(), saveT = null;
  const localDay = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  function flush() {
    clearTimeout(saveT); saveT = null;
    const tmp = FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db)); fs.renameSync(tmp, FILE);
    try {
      const f = path.join(BK, 'db-' + localDay() + '.json');
      if (!fs.existsSync(f)) {
        fs.copyFileSync(FILE, f);
        fs.readdirSync(BK).filter(x => x.startsWith('db-')).sort().slice(0, -30).forEach(x => fs.unlinkSync(path.join(BK, x)));
      }
    } catch (e) {}
  }
  const save = () => { clearTimeout(saveT); saveT = setTimeout(() => { try { flush(); } catch (e) { console.error(e); } }, 250); };

  // ---------- المستخدمون والجلسات ----------
  const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');
  function mkUser(name, username, password, role) {
    username = str(username, 40).trim().toLowerCase();
    if (!/^[a-z0-9._-]{2,30}$/.test(username)) throw new E('اسم المستخدم: أحرف إنجليزية وأرقام فقط');
    if (String(password).length < 4) throw new E('كلمة المرور قصيرة (4 أحرف على الأقل)');
    if (db.users.some(u => u.username === username)) throw new E('اسم المستخدم مستخدم مسبقاً');
    const salt = crypto.randomBytes(8).toString('hex');
    return { id: rid(), name: str(name, 60).trim() || username, username, role: role === 'admin' ? 'admin' : 'seller', salt, hash: hashPw(password, salt) };
  }
  const checkPw = (u, pw) => { const a = Buffer.from(hashPw(pw, u.salt), 'hex'), b = Buffer.from(u.hash, 'hex'); return a.length === b.length && crypto.timingSafeEqual(a, b); };
  function newSession(u) { const t = crypto.randomBytes(24).toString('hex'); db.sessions[t] = { uid: u.id, ts: Date.now() }; try { flush(); } catch (e) {} return t; }
  function userFrom(t) {
    if (!t || !has(db.sessions, t)) return null;
    const s = db.sessions[t];
    if (Date.now() - s.ts > 365 * 864e5) { delete db.sessions[t]; return null; }
    if (Date.now() - s.ts > 864e5) { s.ts = Date.now(); save(); }   // تجديد الجلسة تلقائياً مع الاستخدام
    return db.users.find(u => u.id === s.uid) || null;
  }
  const fails = new Map();

  // ---------- العمليات ----------
  const cleanItem = (d, partial) => {
    const o = {};
    if (!partial || d.n !== undefined) o.n = str(d.n, 120).trim();
    if (!partial || d.c !== undefined) o.c = str(d.c, 60).trim();
    for (const k of ['p', 'cost', 'min']) if (!partial || d[k] !== undefined) o[k] = num(d[k]);
    if (!partial || d.qty !== undefined) o.qty = (d.qty === null || d.qty === '') ? null : num(d.qty);
    if (o.p < 0) o.p = 0;
    return o;
  };
  const redact = (s, u) => u.role === 'admin' ? s : Object.assign({}, s, { lines: s.lines.map(l => ({ id: l.id, n: l.n, c: l.c, q: l.q, p: l.p })) });
  const OPS = {
    'item.save'(u, a) {
      const d = cleanItem(a.data || {}); if (!d.n) throw new E('اسم الصنف مطلوب');
      if (a.id) { if (!has(db.items, a.id)) throw new E('الصنف غير موجود', 404); Object.assign(db.items[a.id], d); return { id: a.id }; }
      const id = rid(); db.items[id] = d; return { id };
    },
    'item.del'(u, a) { if (!has(db.items, a.id)) throw new E('الصنف غير موجود', 404); delete db.items[a.id]; },
    'items.import'(u, a) {
      if (!Array.isArray(a.rows)) throw new E('بيانات غير صحيحة');
      let add = 0, upd = 0;
      for (const row of a.rows) {
        const id = row[0], d = row[1] || {};
        if (!/^[a-z0-9]{6,24}$/.test(id)) continue;
        const c = cleanItem(d, true);
        if (has(db.items, id)) { Object.assign(db.items[id], c); upd++; }
        else if (c.n) { db.items[id] = Object.assign({ n: '', c: '', p: 0, qty: null, cost: 0, min: 0 }, c); add++; }
      }
      return { add, upd };
    },
    'sale.create'(u, a) {
      const rate = db.settings.rate; if (!(rate > 0)) throw new E('سعر الصرف غير صحيح');
      if (!Array.isArray(a.lines) || !a.lines.length) throw new E('الفاتورة فارغة');
      const lines = a.lines.map(l => {
        if (!has(db.items, l.id)) throw new E('أحد الأصناف لم يعد موجوداً');
        const it = db.items[l.id], q = num(l.q); if (!(q > 0)) throw new E('كمية غير صحيحة');
        return { id: l.id, n: it.n, c: it.c || '', q, p: it.p, cost: it.cost || 0 };
      });
      const sub = lines.reduce((s, l) => s + l.q * l.p, 0) * rate;
      const disc = Math.min(Math.max(num(a.disc), 0), sub), total = sub - disc;
      const paid = (a.paid === '' || a.paid == null) ? total : Math.min(Math.max(num(a.paid), 0), total);
      const rest = (total - paid) / rate, cid = a.cust || '';
      if (cid && !has(db.customers, cid)) throw new E('العميل غير موجود');
      if (rest > 0.001 && !cid) throw new E('اختر عميلاً لتسجيل المبلغ المتبقي كدين');
      lines.forEach(l => { const it = db.items[l.id]; if (it.qty != null) it.qty = r3(it.qty - l.q); });
      if (cid && rest > 0.001) db.customers[cid].bal = (db.customers[cid].bal || 0) + rest;
      const s = { id: rid(), ts: Date.now(), no: String(++db.seq), lines, total: total / rate, paid: paid / rate, disc: disc / rate, rate, cust: cid, custName: cid ? db.customers[cid].n : 'نقدي', by: u.name };
      db.sales.push(s);
      return { id: s.id, sale: redact(s, u) };
    },
    'sale.void'(u, a) {
      const i = db.sales.findIndex(s => s.id === a.id); if (i < 0) throw new E('الفاتورة غير موجودة', 404);
      const s = db.sales[i];
      s.lines.forEach(l => { if (has(db.items, l.id) && db.items[l.id].qty != null) db.items[l.id].qty = r3(db.items[l.id].qty + l.q); });
      if (s.cust && has(db.customers, s.cust) && s.total - s.paid > 0.001) db.customers[s.cust].bal = (db.customers[s.cust].bal || 0) - (s.total - s.paid);
      db.sales.splice(i, 1);
    },
    'cust.save'(u, a) {
      const n = str(a.n, 80).trim(); if (!n) throw new E('اسم العميل مطلوب');
      const id = rid(); db.customers[id] = { n, ph: str(a.ph, 30).trim(), bal: 0 }; return { id };
    },
    'cust.del'(u, a) { if (!has(db.customers, a.id)) throw new E('العميل غير موجود', 404); delete db.customers[a.id]; },
    'cust.pay'(u, a) {
      const v = num(a.sdg); if (!(v > 0)) throw new E('المبلغ غير صحيح');
      if (!has(db.customers, a.id)) throw new E('العميل غير موجود', 404);
      db.customers[a.id].bal = (db.customers[a.id].bal || 0) - v / db.settings.rate;
      db.payments.push({ id: rid(), cust: a.id, sdg: v, ts: Date.now(), by: u.name });
    },
    'buy.create'(u, a) {
      if (!has(db.items, a.item)) throw new E('الصنف غير موجود', 404);
      const q = num(a.q), cost = num(a.cost); if (!(q > 0)) throw new E('الكمية غير صحيحة');
      const it = db.items[a.item]; it.qty = r3((it.qty || 0) + q); if (cost > 0) it.cost = cost;
      db.purchases.push({ id: rid(), ts: Date.now(), item: a.item, n: it.n, q, cost, sup: str(a.sup, 80).trim(), by: u.name });
    },
    'settings.save'(u, a) {
      const r = num(a.rate); if (!(r > 0)) throw new E('سعر الصرف غير صحيح');
      db.settings.rate = r; db.settings.shop = str(a.shop, 80).trim(); db.settings.phone = str(a.phone, 40).trim(); db.settings.addr = str(a.addr, 120).trim();
    },
    'exp.add'(u, a) {
      const v = num(a.sdg); if (!(v > 0)) throw new E('المبلغ غير صحيح');
      let ts = Date.now();
      if (/^\d{4}-\d{2}-\d{2}$/.test(a.date || '')) { const t = new Date(a.date + 'T12:00:00').getTime(); if (Number.isFinite(t)) ts = t; }
      const e = { id: rid(), ts, cat: str(a.cat, 40).trim() || 'أخرى', desc: str(a.desc, 120).trim(), sdg: v, by: u.name };
      db.expenses.push(e); return { id: e.id };
    },
    'exp.del'(u, a) {
      const i = db.expenses.findIndex(x => x.id === a.id); if (i < 0) throw new E('غير موجود', 404);
      db.expenses.splice(i, 1);
    },
    'user.add'(u, a) { const nu = mkUser(a.name, a.username, a.password, a.role); db.users.push(nu); return { id: nu.id }; },
    'user.del'(u, a) {
      if (a.id === u.id) throw new E('لا يمكنك حذف حسابك الحالي');
      const i = db.users.findIndex(x => x.id === a.id); if (i < 0) throw new E('المستخدم غير موجود', 404);
      db.users.splice(i, 1); for (const t in db.sessions) if (db.sessions[t].uid === a.id) delete db.sessions[t];
    },
    'user.pass'(u, a) {
      const t = db.users.find(x => x.id === a.id); if (!t) throw new E('المستخدم غير موجود', 404);
      if (String(a.password || '').length < 4) throw new E('كلمة المرور قصيرة (4 أحرف على الأقل)');
      t.salt = crypto.randomBytes(8).toString('hex'); t.hash = hashPw(a.password, t.salt);
      for (const k in db.sessions) if (db.sessions[k].uid === t.id) delete db.sessions[k];
    }
  };

  // ---------- الحالة ----------
  function stateFor(u) {
    const admin = u.role === 'admin', rate = db.settings.rate;
    const items = Object.keys(db.items).map(id => { const i = db.items[id]; return admin ? Object.assign({ id }, i) : { id, n: i.n, c: i.c, p: i.p, qty: i.qty, min: i.min }; });
    const customers = Object.keys(db.customers).map(id => Object.assign({ id }, db.customers[id]));
    const t0 = new Date().setHours(0, 0, 0, 0), n = new Date(), m0 = new Date(n.getFullYear(), n.getMonth(), 1).getTime();
    let today = 0, month = 0, todayCount = 0;
    const d6 = new Date(t0); d6.setDate(d6.getDate() - 6); const w0 = d6.getTime(), week = [0, 0, 0, 0, 0, 0, 0], lim = Math.min(m0, w0);
    for (let i = db.sales.length - 1; i >= 0; i--) {
      const s = db.sales[i]; if (s.ts < lim) break; const v = s.total * s.rate;
      if (s.ts >= m0) month += v;
      if (s.ts >= t0) { today += v; todayCount++; }
      if (s.ts >= w0) { const k = Math.round((new Date(s.ts).setHours(0, 0, 0, 0) - w0) / 864e5); if (k >= 0 && k < 7) week[k] += v; }
    }
    const debt = customers.reduce((a, c) => a + (c.bal || 0), 0) * rate;
    let expMonth = 0; if (admin) for (const e of db.expenses) if (e.ts >= m0) expMonth += e.sdg;
    return {
      v: db.v, me: { id: u.id, name: u.name, username: u.username, role: u.role }, settings: { rate, shop: db.settings.shop, phone: db.settings.phone || '', addr: db.settings.addr || '' },
      items, customers, sales: db.sales.slice(-30).reverse().map(s => redact(s, u)),
      purchases: admin ? db.purchases.slice(-30).reverse() : [],
      users: admin ? db.users.map(x => ({ id: x.id, name: x.name, username: x.username, role: x.role })) : [],
      stats: { today, month, debt, expMonth, todayCount, week: admin ? week : [0, 0, 0, 0, 0, 0, 0] }
    };
  }
  function lanAddresses() {
    const out = [], ifs = os.networkInterfaces();
    for (const k in ifs) for (const a of ifs[k]) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
    return out.sort((a, b) => (/^(192\.168|10\.)/.test(a) ? 0 : 1) - (/^(192\.168|10\.)/.test(b) ? 0 : 1));
  }

  // ---------- HTTP ----------
  const clients = new Set();
  function bump() { db.v++; save(); for (const r of clients) { try { r.write('data: {"v":' + db.v + '}\n\n'); } catch (e) {} } }
  function send(req, res, code, obj, headers) {
    let buf = Buffer.from(JSON.stringify(obj));
    const h = Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers);
    if (buf.length > 1024 && /gzip/.test(req.headers['accept-encoding'] || '')) { buf = zlib.gzipSync(buf); h['Content-Encoding'] = 'gzip'; }
    res.writeHead(code, h); res.end(buf);
  }
  function body(req, limit) {
    return new Promise((ok, no) => {
      let n = 0; const ch = [];
      req.on('data', c => { n += c.length; if (n > limit) { no(new E('حجم البيانات كبير جداً', 413)); req.destroy(); } else ch.push(c); });
      req.on('end', () => { try { ok(JSON.parse(Buffer.concat(ch).toString() || '{}')); } catch (e) { no(new E('بيانات غير صحيحة')); } });
      req.on('error', no);
    });
  }
  const dayStart = s => new Date(s + 'T00:00:00').getTime(), dayEnd = s => new Date(s + 'T23:59:59.999').getTime();

  async function api(req, res, url, p) {
    const m = req.method, ip = req.socket.remoteAddress;
    if (p === '/api/status' && m === 'GET') return send(req, res, 200, { setup: db.users.length === 0, shop: db.settings.shop });
    if (p === '/api/setup' && m === 'POST') {
      if (db.users.length) throw new E('تم الإعداد مسبقاً', 403);
      const b = await body(req, 1e4), u = mkUser(b.name, b.username, b.password, 'admin');
      db.users.push(u); if (num(b.rate) > 0) db.settings.rate = num(b.rate); if (b.shop) db.settings.shop = str(b.shop, 80).trim(); bump(); flush();
      return send(req, res, 200, { token: newSession(u) });
    }
    if (p === '/api/login' && m === 'POST') {
      const f = fails.get(ip) || { n: 0, t: Date.now() };
      if (Date.now() - f.t > 3e5) { f.n = 0; f.t = Date.now(); }
      if (f.n >= 10) throw new E('محاولات كثيرة. حاول مرة أخرى بعد 5 دقائق', 429);
      const b = await body(req, 1e4), un = str(b.username, 40).trim().toLowerCase(), u = db.users.find(x => x.username === un);
      if (!u || !checkPw(u, b.password)) { f.n++; fails.set(ip, f); await new Promise(r => setTimeout(r, 600)); throw new E('اسم المستخدم أو كلمة المرور غير صحيحة', 401); }
      fails.delete(ip);
      return send(req, res, 200, { token: newSession(u) });
    }
    const hdr = req.headers.authorization || '', tok = hdr.startsWith('Bearer ') ? hdr.slice(7) : url.searchParams.get('t');
    const u = userFrom(tok);
    if (!u) throw new E('انتهت الجلسة. يرجى تسجيل الدخول مرة أخرى', 401);
    const admin = u.role === 'admin';

    if (p === '/api/logout' && m === 'POST') { delete db.sessions[tok]; save(); return send(req, res, 200, { ok: true }); }
    if (p === '/api/state' && m === 'GET') return send(req, res, 200, stateFor(u));
    if (p === '/api/events' && m === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      res.write('data: {"v":' + db.v + '}\n\n'); clients.add(res); req.on('close', () => clients.delete(res)); return;
    }
    if (p === '/api/info' && m === 'GET') return send(req, res, 200, { addresses: lanAddresses().map(a => 'http://' + a + ':' + opts.getPort()), dataDir: DATA });
    if (p === '/api/op' && m === 'POST') {
      const b = await body(req, 20e6);
      if (!has(OPS, b.op)) throw new E('عملية غير معروفة', 404);
      if (ADMIN_OPS.has(b.op) && !admin) throw new E('ليست لديك صلاحية لهذه العملية', 403);
      const r = OPS[b.op](u, b.args || {}); bump();
      return send(req, res, 200, Object.assign({ ok: true }, r));
    }
    const dRe = /^\d{4}-\d{2}-\d{2}$/, dArg = k => { const v = url.searchParams.get(k) || ''; return dRe.test(v) ? v : localDay(); };
    if (p === '/api/sales' && m === 'GET') {
      const fs_ = admin ? dArg('f') : localDay(), ts_ = admin ? dArg('t') : localDay(), f = dayStart(fs_), t = dayEnd(ts_);
      const out = []; for (let i = db.sales.length - 1; i >= 0 && out.length < 5000; i--) { const s = db.sales[i]; if (s.ts < f) break; if (s.ts <= t) out.push(redact(s, u)); }
      const expenses = admin ? db.expenses.filter(e => e.ts >= f && e.ts <= t).sort((a, b) => b.ts - a.ts) : [];
      return send(req, res, 200, { sales: out, expenses });
    }
    if (p === '/api/expenses' && m === 'GET') {
      if (!admin) throw new E('ليست لديك صلاحية', 403);
      const f = dayStart(dArg('f')), t = dayEnd(dArg('t'));
      return send(req, res, 200, { expenses: db.expenses.filter(e => e.ts >= f && e.ts <= t).sort((a, b) => b.ts - a.ts) });
    }
    const cm = p.match(/^\/api\/cust\/([a-z0-9]+)$/);
    if (cm && m === 'GET') {
      const id = cm[1], sales = [], pays = [];
      for (let i = db.sales.length - 1; i >= 0 && sales.length < 200; i--) { const s = db.sales[i]; if (s.cust === id && s.total - s.paid > 0.001) sales.push(redact(s, u)); }
      for (let i = db.payments.length - 1; i >= 0 && pays.length < 200; i--) if (db.payments[i].cust === id) pays.push(db.payments[i]);
      return send(req, res, 200, { sales, payments: pays });
    }
    if (p === '/api/backup' && m === 'GET') {
      if (!admin) throw new E('ليست لديك صلاحية', 403);
      const copy = Object.assign({}, db, { sessions: {} });
      return send(req, res, 200, copy, { 'Content-Disposition': 'attachment; filename="backup-' + localDay() + '.json"' });
    }
    if (p === '/api/restore' && m === 'POST') {
      if (!admin) throw new E('ليست لديك صلاحية', 403);
      const b = await body(req, 200e6);
      if (!b || typeof b.items !== 'object' || !Array.isArray(b.users) || !b.users.length || !Array.isArray(b.sales)) throw new E('الملف ليس نسخة احتياطية صحيحة');
      try { fs.copyFileSync(FILE, path.join(BK, 'before-restore-' + Date.now() + '.json')); } catch (e) {}
      const v = db.v; db = Object.assign({ seq: 1000, purchases: [], payments: [], expenses: [], customers: {}, settings: { rate: 11000, shop: '', phone: '' } }, b, { sessions: {}, v: v + 1 });
      flush(); for (const r of clients) { try { r.write('data: {"v":' + db.v + '}\n\n'); } catch (e) {} }
      return send(req, res, 200, { ok: true });
    }
    throw new E('غير موجود', 404);
  }

  function serveStatic(req, res, p) {
    if (p.startsWith('/fonts/')) {   // خط Tajawal المحلي (من حزمة @fontsource/tajawal) ليعمل بدون إنترنت
      const base = path.join(__dirname, 'node_modules', '@fontsource', 'tajawal');
      let rel; try { rel = decodeURIComponent(p.slice(7)); } catch (e) { res.writeHead(400); return res.end(); }
      const f = path.resolve(path.join(base, rel));
      if (!f.startsWith(base) || !/\.(css|woff2?)$/.test(f)) { res.writeHead(404); return res.end(); }
      return fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'max-age=604800' }); res.end(d); });
    }
    if (p === '/xlsx.min.js') {
      let f; try { f = require.resolve('xlsx/dist/xlsx.full.min.js'); } catch (e) { res.writeHead(404); return res.end(); }
      return fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': MIME['.js'], 'Cache-Control': 'max-age=86400' }); res.end(d); });
    }
    let rel; try { rel = decodeURIComponent(p); } catch (e) { res.writeHead(400); return res.end(); }
    const f = path.resolve(path.join(PUB, rel === '/' ? 'index.html' : rel));
    if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
    fs.readFile(f, (e, d) => {
      if (e) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('غير موجود'); }
      const ext = path.extname(f).toLowerCase();
      const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' || ext === '.json' || ext === '.js' ? 'no-cache' : 'max-age=3600' };
      if (d.length > 1024 && /gzip/.test(req.headers['accept-encoding'] || '') && /html|js|json|css|svg/.test(ext)) { d = zlib.gzipSync(d); h['Content-Encoding'] = 'gzip'; }
      res.writeHead(200, h); res.end(d);
    });
  }

  let port = 0, ping = null;
  opts.getPort = () => port;
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x'), p = url.pathname;
      if (p.startsWith('/api/')) await api(req, res, url, p); else serveStatic(req, res, p);
    } catch (e) {
      if (!res.headersSent) send(req, res, e.c || 500, { error: e.c ? e.message : 'خطأ داخلي في الخادم' }); else res.end();
      if (!e.c) console.error(e);
    }
  });
  return {
    listen(start) {
      return new Promise((ok, no) => {
        let p = start;
        const tryListen = () => { server.once('error', e => { if (e.code === 'EADDRINUSE' && p < start + 10) { p++; tryListen(); } else no(e); }); server.listen(p, '0.0.0.0', () => { port = p; ping = setInterval(() => clients.forEach(r => { try { r.write(': ping\n\n'); } catch (e) {} }), 20000); ok(p); }); };
        tryListen();
      });
    },
    flush() { try { flush(); } catch (e) { console.error(e); } },
    close() { clearInterval(ping); clients.forEach(r => { try { r.end(); } catch (e) {} }); server.close(); if (server.closeAllConnections) server.closeAllConnections(); },
    addresses: () => lanAddresses().map(a => 'http://' + a + ':' + port),
    getPort: () => port
  };
}

module.exports = { createServer };

// تشغيل مباشر بدون Electron:  node server.js
if (require.main === module) {
  const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data');
  const s = createServer({ dataDir, publicDir: path.join(__dirname, 'public'), shopName: '' });
  s.listen(+process.env.PORT || 3000).then(p => { console.log('http://localhost:' + p); s.addresses().forEach(a => console.log('  ' + a)); });
  process.on('SIGINT', () => { s.flush(); process.exit(0); });
}
