@echo off
chcp 65001 >nul
title Build
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Download it from https://nodejs.org then run this file again.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto fail
call npm run dist
if errorlevel 1 goto fail
echo.
echo DONE. The installer is inside the "dist" folder: Makhzani-Setup-1.0.0.exe
start "" dist
pause
exit /b 0
:fail
echo.
echo Build failed. Check your internet connection and try again.
pause
